package com.jb.students.services;

import com.jb.students.beans.Student;
import com.jb.students.exceptions.StudentCustomException;
import com.jb.students.repos.StudentRepository;

import java.util.List;

public interface StudentService
{
    void addStudent(Student student) throws StudentCustomException;
    void deleteStudent(long studentId) throws StudentCustomException;
    List<Student> getAllStudents();
    Student getSingleStudent(long studentId) throws StudentCustomException;
    List<Student> getStudentsByName(String str);
    double getStudentAverageGrade(long studentId) throws StudentCustomException;
}
