package com.jb.students.services;
import com.jb.students.beans.Student;
import com.jb.students.exceptions.ErrMsg;
import com.jb.students.exceptions.StudentCustomException;
import com.jb.students.repos.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class StudentServiceImpl implements StudentService
{
    @Autowired
    private StudentRepository studentRepository;

    @Override
    public void addStudent(Student student) throws StudentCustomException {
        boolean exists = studentRepository.existsById(student.getId());
        if (exists)
        {
            throw new StudentCustomException(ErrMsg.ID_ALREADY_EXIST);
        }
        student.getGrades().forEach(g->g.setStudent(student));
        studentRepository.save(student);
    }

    @Override
    public void deleteStudent(long studentId) throws StudentCustomException
    {
        boolean exists = studentRepository.existsById(studentId);
        if (!exists)
        {
            throw new StudentCustomException(ErrMsg.ID_NOT_FOUND);
        }
        studentRepository.deleteById(studentId);
    }

    @Override
    public List<Student> getAllStudents()
    {
        return studentRepository.findAll();
    }

    @Override
    public Student getSingleStudent(long studentId) throws StudentCustomException
    {
        return studentRepository.findById(studentId).orElseThrow(()-> new StudentCustomException(ErrMsg.ID_NOT_FOUND));
    }

    @Override
    public List<Student> getStudentsByName(String str)
    {
        return studentRepository.findByNameContaining(str);
    }

    @Override
    public double getStudentAverageGrade(long studentId) throws StudentCustomException
    {
        boolean exists = studentRepository.existsById(studentId);
        if (!exists)
        {
            throw new StudentCustomException(ErrMsg.ID_NOT_FOUND);
        }
        return studentRepository.getStudentAverageGradeByStudentId(studentId);
    }
}
