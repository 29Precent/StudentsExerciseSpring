package com.jb.students.advice;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ErrDetails
{
    private final String key = "Spring Framework Test :)";
    private String value;
}
