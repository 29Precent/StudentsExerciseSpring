package com.jb.students.beans;

public enum Topic
{
    PROJECT1,
    PROJECT2,
    PROJECT3;
}
