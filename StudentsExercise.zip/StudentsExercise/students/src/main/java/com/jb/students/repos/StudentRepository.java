package com.jb.students.repos;

import com.jb.students.beans.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface StudentRepository extends JpaRepository<Student,Long>
{
    boolean existsById(long studentId);
//    List<Student> findAllByOrderByNameAsc();
    List<Student> findByNameContaining(String str);

    @Query(value = "SELECT avg(score) AS averageScore FROM `students&grades`.`grades` where student_id = ?",nativeQuery = true)
    double getStudentAverageGradeByStudentId(long studentId);
}
