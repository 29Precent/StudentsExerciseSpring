package com.jb.students.clr.on;

import com.jb.students.beans.Grade;
import com.jb.students.beans.Student;
import com.jb.students.beans.Topic;
import com.jb.students.services.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.swing.text.html.parser.Entity;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

@Component
@Order(3)
public class SchoolTesting implements CommandLineRunner
{

    @Autowired
    private StudentService studentService;
    @Autowired
    private RestTemplate restTemplate;

    @Value("${url}")
    private String url;

    @Override
    public void run(String... args) throws Exception
    {
        System.out.println("__________________________________________________________________________");
        System.out.println("REST TEMPLATE");
        System.out.println("@@@@@ ADD A STUDENT @@@@@");
        Grade g1 = Grade.builder()
                .score(46)
                .topic(Topic.PROJECT1)
                .build();
        Grade g2 = Grade.builder()
                .score(83)
                .topic(Topic.PROJECT2)
                .build();
        Grade g3 = Grade.builder()
                .score(76)
                .topic(Topic.PROJECT3)
                .build();

        Student s1 = Student.builder()
                .name("Simha Raba")
                .isActive(false)
                .grades(List.of(g1,g2,g3))
                .birthday(Date.valueOf(LocalDate.now().minusYears(63)))
                .build();
        g1.setStudent(s1);
        g2.setStudent(s1);
        g3.setStudent(s1);
        ResponseEntity<String> res = restTemplate.postForEntity(url,s1,String.class);
        System.out.println((res.getStatusCodeValue()==201)?"Done successfully":"Could not done successfully.");

        System.out.println("@@@@@ Get Student #7 (the just added student) @@@@@");
        Student studentFromDB = restTemplate.getForObject(url+"/7",Student.class);
        System.out.println(studentFromDB);

        System.out.println("@@@@@ GET ALL Students @@@@@");
        Student[] students = restTemplate.getForObject(url,Student[].class);
        Arrays.stream(students).forEach(System.out::println);

        System.out.println("@@@@@ DELETE A STUDENT (student #3)");
        Student toDelete = studentService.getSingleStudent(3);
        HttpEntity<Student> studentToDelete = new HttpEntity<>(toDelete);
        ResponseEntity<String> res1 = restTemplate.exchange(url+"/3", HttpMethod.DELETE, studentToDelete, String.class);
        System.out.println(res1.getStatusCodeValue() == 204 ? "Done successfully" : "Could not done successfully");
        studentService.getAllStudents().forEach(System.out::println);

        System.out.println("@@@@@ GET STUDENT AVERAGE GRADE BY ID (student #6)");
        double avg = restTemplate.getForObject(url+"/avg-grade/6",double.class);
        System.out.println(avg);

        System.out.println("@@@@@ GET ALL STUDENTS BY NAME (DENNIS) @@@@@");
        Student[] studentsByName = restTemplate.getForObject(url+"/name?name=dennis",Student[].class);
        Arrays.stream(studentsByName).forEach(System.out::println);

    }
}
