package com.jb.students.exceptions;

public class StudentCustomException extends Exception
{
    public StudentCustomException(ErrMsg errMsg)
    {
        super(errMsg.getMessage());
    }
}
