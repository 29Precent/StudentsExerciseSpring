package com.jb.students.clr.on;

import com.jb.students.beans.Grade;
import com.jb.students.beans.Student;
import com.jb.students.beans.Topic;
import com.jb.students.services.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

@Component
@Order(2)
public class ServiceTesting implements CommandLineRunner
{
    @Autowired
    private StudentService studentService;
    @Override
    public void run(String... args) throws Exception
    {
        System.out.println("__________________________________________________________________________");
        System.out.println("@@@@@ START OF SERVICE TESTING @@@@@");
        System.out.println("@@@@@ ADD A STUDENT @@@@@");

        Grade g1 = Grade.builder()
                .score(96)
                .topic(Topic.PROJECT1)
                .build();
        Grade g2 = Grade.builder()
                .score(74)
                .topic(Topic.PROJECT2)
                .build();
        Grade g3 = Grade.builder()
                .score(81)
                .topic(Topic.PROJECT3)
                .build();

        Student s1 = Student.builder()
                .name("Tony Armadil")
                .isActive(false)
                .grades(List.of(g1,g2,g3))
                .birthday(Date.valueOf(LocalDate.now().minusYears(22)))
                .build();

        g1.setStudent(s1);
        g2.setStudent(s1);
        g3.setStudent(s1);

        studentService.addStudent(s1);
        studentService.getAllStudents().forEach(System.out::println);

        System.out.println("@@@@@ DELETE A STUDENT (student 2) @@@@@");
        studentService.deleteStudent(2);
        studentService.getAllStudents().forEach(System.out::println);

        System.out.println("@@@@@ GET A SINGLE STUDENT (student 1) @@@@@");
        System.out.println(studentService.getSingleStudent(1));

        System.out.println("@@@@@ GET STUDENTS BY NAME (Dennis) @@@@@");
        studentService.getStudentsByName("Dennis").forEach(System.out::println);

        System.out.println("@@@@@ GET STUDENT AVERAGE GRADE BY STUDENT ID (STUDENT 3) @@@@@");
        System.out.println(studentService.getStudentAverageGrade(3));

    }
}
