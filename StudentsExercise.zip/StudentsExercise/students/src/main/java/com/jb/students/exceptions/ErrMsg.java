package com.jb.students.exceptions;

import lombok.Getter;

@Getter
public enum ErrMsg
{
    ID_ALREADY_EXIST("Cannot add a student with exist id."),
    ID_NOT_FOUND("Cannot found this student id."),
    ID_NOT_FOUND3("....");

    private String message;

    ErrMsg(String message)
    {
        this.message = message;
    }
}
