package com.jb.students.clr.on;

import com.jb.students.beans.Grade;
import com.jb.students.beans.Student;
import com.jb.students.beans.Topic;
import com.jb.students.repos.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

@Component
@Order(1)
public class Init implements CommandLineRunner
{
    @Autowired
    private StudentRepository studentRepository;
    @Override
    public void run(String... args) throws Exception
    {
        Grade g1 = Grade.builder()
                .score(50)
                .topic(Topic.PROJECT1)
                .build();
        Grade g2 = Grade.builder()
                .score(80)
                .topic(Topic.PROJECT2)
                .build();
        Grade g3 = Grade.builder()
                .score(67)
                .topic(Topic.PROJECT3)
                .build();

        Grade g4 = Grade.builder()
                .score(83)
                .topic(Topic.PROJECT1)
                .build();
        Grade g5 = Grade.builder()
                .score(56)
                .topic(Topic.PROJECT2)
                .build();
        Grade g6 = Grade.builder()
                .score(72)
                .topic(Topic.PROJECT3)
                .build();

        Grade g7 = Grade.builder()
                .score(42)
                .topic(Topic.PROJECT1)
                .build();
        Grade g8 = Grade.builder()
                .score(59)
                .topic(Topic.PROJECT2)
                .build();
        Grade g9 = Grade.builder()
                .score(100)
                .topic(Topic.PROJECT3)
                .build();

        Grade g10 = Grade.builder()
                .score(93)
                .topic(Topic.PROJECT1)
                .build();
        Grade g11 = Grade.builder()
                .score(79)
                .topic(Topic.PROJECT2)
                .build();
        Grade g12 = Grade.builder()
                .score(85)
                .topic(Topic.PROJECT3)
                .build();

        Grade g13 = Grade.builder()
                .score(98)
                .topic(Topic.PROJECT1)
                .build();
        Grade g14 = Grade.builder()
                .score(35)
                .topic(Topic.PROJECT2)
                .build();
        Grade g15 = Grade.builder()
                .score(68)
                .topic(Topic.PROJECT3)
                .build();

        Student s1 = Student.builder()
                .name("Dennis Hatool")
                .isActive(true)
                .grades(List.of(g1,g2,g3))
                .birthday(Date.valueOf(LocalDate.now().minusYears(25)))
                .build();
        Student s2 = Student.builder()
                .name("Moti Tarnegol")
                .isActive(false)
                .grades(List.of(g4,g5,g6))
                .birthday(Date.valueOf(LocalDate.now().minusYears(29)))
                .build();
        Student s3 = Student.builder()
                .name("Luka Modric")
                .isActive(true)
                .grades(List.of(g7,g8,g9))
                .birthday(Date.valueOf(LocalDate.now().minusYears(37)))
                .build();
        Student s4 = Student.builder()
                .name("Dennis Namer")
                .isActive(true)
                .grades(List.of(g10,g11,g12))
                .birthday(Date.valueOf(LocalDate.now().minusYears(19)))
                .build();
        Student s5 = Student.builder()
                .name("Roni Karish")
                .isActive(true)
                .grades(List.of(g13,g14,g15))
                .birthday(Date.valueOf(LocalDate.now().minusYears(40)))
                .build();

        g1.setStudent(s1);
        g2.setStudent(s1);
        g3.setStudent(s1);

        g4.setStudent(s2);
        g5.setStudent(s2);
        g6.setStudent(s2);

        g7.setStudent(s3);
        g8.setStudent(s3);
        g9.setStudent(s3);

        g10.setStudent(s4);
        g11.setStudent(s4);
        g12.setStudent(s4);

        g13.setStudent(s5);
        g14.setStudent(s5);
        g15.setStudent(s5);

        studentRepository.saveAllAndFlush(List.of(s1,s2,s3,s4,s5));
        System.out.println("Our Students : ");
        studentRepository.findAll().forEach(System.out::println);


    }
}
