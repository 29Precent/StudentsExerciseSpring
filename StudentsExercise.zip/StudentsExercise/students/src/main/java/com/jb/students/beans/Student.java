package com.jb.students.beans;

import lombok.*;

import javax.persistence.*;
import java.sql.Date;
import java.util.List;
@Entity
@Table(name = "students")
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class Student
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(nullable = false,length = 40)
    private String name;
    private Date birthday;
    private boolean isActive;
    @OneToMany(mappedBy = "student",cascade = {CascadeType.PERSIST,CascadeType.MERGE,CascadeType.REMOVE})
    @Singular
    private List<Grade> grades;
}
