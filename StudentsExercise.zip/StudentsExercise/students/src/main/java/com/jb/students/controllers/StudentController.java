package com.jb.students.controllers;

import com.jb.students.beans.Student;
import com.jb.students.exceptions.StudentCustomException;
import com.jb.students.services.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController
{
    @Autowired
    private StudentService studentService;

    @GetMapping
    public List<Student> getAllStudents()
    {
        return studentService.getAllStudents();
    }

    @GetMapping("/{id}")
    public Student getSingleStudent(@PathVariable long id) throws StudentCustomException
    {
        return studentService.getSingleStudent(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public void addStudent(@RequestBody Student student) throws StudentCustomException
    {
        studentService.addStudent(student);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteStudent(@PathVariable int id) throws StudentCustomException {
        studentService.deleteStudent(id);
    }

    @GetMapping("/avg-grade/{id}")
    public double getAverageGradeByStudentId(@PathVariable int id) throws StudentCustomException
    {
        return studentService.getStudentAverageGrade(id);
    }

    @GetMapping("/name")
    public List<Student> getStudentsByName(@RequestParam String name)
    {
        return studentService.getStudentsByName(name);
    }


}
